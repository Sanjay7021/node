import ImageModel, { IImage } from '../models/imageModel';

export const createImage = async (filename: string, productId: string): Promise<IImage> => {
    const image = new ImageModel({ filename, product: productId });
    return await image.save();
};

export const getImageById = async (id: string): Promise<IImage | null> => {
    return await ImageModel.findById(id).exec();
};

export const deleteImage = async (id: string): Promise<IImage | null> => {
    return await ImageModel.findByIdAndDelete(id).exec();
};