import CategoryModel, { ICategory } from '../models/categoryModel';

export const createCategory = async (name: string, description: string): Promise<ICategory> => {
    const category = new CategoryModel({ name, description });
    return await category.save();
};

export const getCategoryById = async (id: string): Promise<ICategory | null> => {
    return await CategoryModel.findById(id).exec();
};

export const updateCategory = async (id: string, name: string, description: string): Promise<ICategory | null> => {
    return await CategoryModel.findByIdAndUpdate(id, { name, description }, { new: true }).exec();
};

export const deleteCategory = async (id: string): Promise<ICategory | null> => {
    return await CategoryModel.findByIdAndDelete(id).exec();
};

export const getAllCategories = async (): Promise<ICategory[]> => {
    return await CategoryModel.find().exec();
};