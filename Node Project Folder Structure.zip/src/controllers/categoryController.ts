import { Request, Response } from 'express';
import { createCategory, getCategoryById, getAllCategories, updateCategory, deleteCategory } from '../services/categoryService';

export const createCategoryController = async (req: Request, res: Response): Promise<void> => {
    try {
        const { name, description } = req.body;
        const category = await createCategory(name, description);
        res.status(201).json(category);
    } catch (error) {
        res.status(500).json({ error: error });
    }
};

export const getCategoryByIdController = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;
        const category = await getCategoryById(id);
        if (!category) {
            res.status(404).json({ error: 'Category not found' });
            return;
        }
        res.json(category);
    } catch (error) {
        res.status(500).json({ error: error });
    }
};
export const getAllCategoriesController = async (req: Request, res: Response): Promise<void> => {
    try {
        const categories = await getAllCategories();
        res.json(categories);
    } catch (error) {
        res.status(500).json({ error: error });
    }
};
export const updateCategoryController = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;
        console.log(id)
        const { name, description } = req.body;
        const updatedCategory = await updateCategory(id, name, description);
        if (!updatedCategory) {
            res.status(404).json({ error: 'Category not found' });
            return;
        }
        res.json(updatedCategory);
    } catch (error) {
        res.status(500).json({ error: error });
    }
};

export const deleteCategoryController = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;
        const deletedCategory = await deleteCategory(id);
        if (!deletedCategory) {
            res.status(404).json({ error: 'Category not found' });
            return;
        }
        res.json({ message: 'Category deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error });
    }
};
