import mongoose, { Schema, Document } from 'mongoose';
import { IProduct } from './productModel';

export interface IImage extends Document {
    filename: string;
    product: IProduct['_id'];
}

const imageSchema: Schema = new Schema({
    filename: { type: String, required: true },
    product: { type: Schema.Types.ObjectId, ref: 'Product', required: true }
});

export default mongoose.model<IImage>('Image', imageSchema);