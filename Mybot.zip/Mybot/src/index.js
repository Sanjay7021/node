import { GoogleGenerativeAI } from '@google/generative-ai'
const genAI = new GoogleGenerativeAI("AIzaSyDqeMkEXssA897oBvwMlC21vXUdvLA6gcc")
 
const run = async () => {
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash-latest" })
    const prompt = "how do i access query parameters in next js get request (api) in latest app router use next/server liberary"
 
    const { totalTokens } = await model.countTokens(prompt)
    console.log("Token Count", totalTokens);
 
    const result = await model.generateContent(prompt);
    const response = result.response;
    const text = response.text();
    console.log(text);
}
 
run()