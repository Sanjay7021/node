import express from 'express';
import * as imageController from '../controllers/imageController';
import { upload } from '../utils/fileupload'

const router = express.Router();

router.post('/', upload, imageController.uploadImage);
router.get('/:id', imageController.getImageByIdd);
router.delete('/:id', imageController.deleteImagee);

export default router;