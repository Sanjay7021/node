import mongoose from 'mongoose';
import ProductModel, { IProduct } from '../models/productModel';
import categoryModel from '../models/categoryModel';

export const createProduct = async (name: string, description: string, category: string): Promise<IProduct> => {
    //const categoryIdString = '631eced96065aae03f7912b'; // Example categoryId string

    const product = new ProductModel({ name, description, category: category });
    return await product.save();
};

export const getProductById = async (id: string): Promise<IProduct | null> => {
    return await ProductModel.findById(id).exec();
};

export const updateProduct = async (id: string, name: string, description: string, category: string): Promise<IProduct | null> => {
    return await ProductModel.findByIdAndUpdate(id, { name, description, category }, { new: true }).exec();
};

export const deleteProduct = async (id: string): Promise<IProduct | null> => {
    return await ProductModel.findByIdAndDelete(id).exec();
};