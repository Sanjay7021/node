import { Request, Response } from 'express';
import { createProduct, getProductById, deleteProduct, updateProduct } from '../services/productService';

export const createProductt = async (req: Request, res: Response) => {
    try {
        const { name, description, category } = req.body;
        console.log(name, description, category)
        const product = await createProduct(name, description, category);
        res.status(201).json(product);
    } catch (error) {
        res.status(500).json({ error: error });
    }
};

export const getProductByIdd = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const product = await getProductById(id);
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json(product);
    } catch (error) {
        res.status(500).json({ error: error });
    }
};

export const updateProductt = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { name, description, category } = req.body;
        const updatedProduct = await updateProduct(id, name, description, category);
        if (!updatedProduct) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json(updatedProduct);
    } catch (error) {
        res.status(500).json({ error: error });
    }
};

export const deleteProductt = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const deletedProduct = await deleteProduct(id);
        if (!deletedProduct) {
            return res.status(404).json({ error: 'Product not found' });
        }
        res.json({ message: 'Product deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error });
    }
};