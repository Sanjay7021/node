import express from 'express';
import * as productController from '../controllers/productController';

const router = express.Router();

router.post('/', productController.createProductt);
router.get('/:id', productController.getProductByIdd);
router.put('/:id', productController.updateProductt);
router.delete('/:id', productController.deleteProductt);

export default router;