import express, { Request, Response } from 'express';
import { createImage, deleteImage, getImageById } from '../services/imageService';

export const uploadImage = async (req: Request, res: Response) => {
    console.log(req)
    console.log(req.file)
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }
        const { filename } = req.file;
        const { productId } = req.body; // Assuming productId is sent in the request body
        const image = await createImage(filename, productId);
        res.status(201).json(image);
    } catch (error) {
        res.status(500).json({ error: error });
    }
};

export const getImageByIdd = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const image = await getImageById(id);
        if (!image) {
            return res.status(404).json({ error: 'Image not found' });
        }
        res.json(image);
    } catch (error) {
        res.status(500).json({ error: error });
    }
};

export const deleteImagee = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const deletedImage = await deleteImage(id);
        if (!deletedImage) {
            return res.status(404).json({ error: 'Image not found' });
        }
        res.json({ message: 'Image deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error });
    }
};