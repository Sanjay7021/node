import mongoose, { Schema, Document } from 'mongoose';
import { ICategory } from './categoryModel';

export interface IProduct extends Document {
    name: string;
    description?: string;
    category: string;

}

const productSchema: Schema = new Schema({
    name: { type: String, required: true },
    description: { type: String },
    category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },

});

export default mongoose.model<IProduct>('Product', productSchema);